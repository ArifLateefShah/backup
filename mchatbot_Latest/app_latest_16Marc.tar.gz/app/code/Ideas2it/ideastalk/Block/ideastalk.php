<?php
namespace Ideas2it\ideastalk\Block;
class ideastalk extends \Magento\Framework\View\Element\Template
{
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
}
